angular.module('main').controller("homeCtrl",[ "$scope", function($scope){
    $scope.nombre = "miApp";

}]);