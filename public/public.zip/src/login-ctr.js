angular.module('main').controller("loginCtrl",[ "$scope", function($scope){
    $scope.loginFacebook="";

}]);
