angular.module("main").controller("registrationCtrl",["$scope","$rootScope",function($scope,$rootScope){
    $scope.userRegistration={
        provinces : null
    }
 

}])